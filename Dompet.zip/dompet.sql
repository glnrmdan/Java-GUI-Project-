-- phpMyAdmin SQL Dump
-- version 5.0.4
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jun 13, 2021 at 05:21 AM
-- Server version: 10.4.16-MariaDB
-- PHP Version: 7.4.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `dompet`
--

-- --------------------------------------------------------

--
-- Table structure for table `danadarurat`
--

CREATE TABLE `danadarurat` (
  `tbTanggal` varchar(100) NOT NULL,
  `tbMasuk` varchar(100) NOT NULL,
  `tbKeluar` varchar(100) NOT NULL,
  `tbTotal` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `danadarurat`
--

INSERT INTO `danadarurat` (`tbTanggal`, `tbMasuk`, `tbKeluar`, `tbTotal`) VALUES
('2021-06-12', '500000', '450000', '50000'),
('2021-06-12', '1000000', '450000', '550000'),
('2021-06-12', '1000000', '680000', '220000');

-- --------------------------------------------------------

--
-- Table structure for table `investasi`
--

CREATE TABLE `investasi` (
  `tbTanggal` varchar(100) NOT NULL,
  `tbMasuk` varchar(100) NOT NULL,
  `tbKeluar` varchar(100) NOT NULL,
  `tbTotal` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `investasi`
--

INSERT INTO `investasi` (`tbTanggal`, `tbMasuk`, `tbKeluar`, `tbTotal`) VALUES
('2021-06-12', '200000', '0', '200000'),
('2021-06-12', '5000000', '3500000', '1500000'),
('2021-06-12', '200000', '0', '0'),
('2021-06-12', '500000', '250000', '250000'),
('2021-06-13', '1000000', '0', '1000000');

-- --------------------------------------------------------

--
-- Table structure for table `registrasi`
--

CREATE TABLE `registrasi` (
  `id` int(50) NOT NULL,
  `nama` varchar(100) NOT NULL,
  `username` varchar(100) NOT NULL,
  `pass` varchar(100) NOT NULL,
  `repass` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `registrasi`
--

INSERT INTO `registrasi` (`id`, `nama`, `username`, `pass`, `repass`) VALUES
(1, 'Galan Ramadan', 'alan', 'ALAN12', 'ALAN12'),
(2, 'Harya Ramadan', 'Harya', 'harya12', 'harya12'),
(3, 'Galan Ramadan Harya Galib', 'glnrmdan', 'glnrmdan12', 'glnrmdan12'),
(15, 'Galan', 'Haruya', '123', '123'),
(16, 'Haruya', 'Haruya', '123', '123'),
(17, 'sutejo', 'Tejo', '123', '123'),
(18, 'Galan Ramadan', 'galan', '123', '123'),
(20, 'Aji Bagas', 'aji', '123', '123'),
(21, 'alan', 'alan', '123', '123');

-- --------------------------------------------------------

--
-- Table structure for table `tabung`
--

CREATE TABLE `tabung` (
  `tbTanggal` varchar(100) NOT NULL,
  `tbMasuk` varchar(100) NOT NULL,
  `tbKeluar` varchar(100) NOT NULL,
  `tbTotal` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tabung`
--

INSERT INTO `tabung` (`tbTanggal`, `tbMasuk`, `tbKeluar`, `tbTotal`) VALUES
('2021-06-12', '100000', '0', '100000'),
('2021-06-12', '100000', '0', '100000'),
('2021-06-12', '1000000', '200000', '800000'),
('2021-06-12', '500000', '100000', '400000');

-- --------------------------------------------------------

--
-- Table structure for table `total`
--

CREATE TABLE `total` (
  `total_semua` varchar(100) NOT NULL,
  `total_inves` varchar(100) NOT NULL,
  `total_tabung` varchar(100) NOT NULL,
  `total_darurat` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `registrasi`
--
ALTER TABLE `registrasi`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `registrasi`
--
ALTER TABLE `registrasi`
  MODIFY `id` int(50) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=22;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
