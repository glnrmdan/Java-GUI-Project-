package dashboard;

/**
 *
 * @author glnrmdan
 */
public class Penampungan extends Abstrak {
    //Enkapsilasi
    public int getHitung() {
        return hitung;
    }
    public void setHitung(int hitung) {
        this.hitung = hitung;
    }
    
    public int getMasuk() {
        return masuk;
    }
    public void setMasuk(int masuk) {
        this.masuk = masuk;
    }
    
    public int getKeluar() {
        return keluar;
    }
     public void setKeluar(int keluar) {
        this.keluar = keluar;
    }
     
    public int getTotal() {
        return total;
    }
    public void setTotal(int total){
        this.total = total;
    }
     
    @Override
     int hitung(){
         System.out.println("Gas Hitung Gan !");
         return 0;
     }
     
     @Override
     int masuk(){
         System.out.println("Menampung Nilai Masuk");
         return 0;
     }
     
     @Override
     int keluar(){
         System.out.println("Menampung Nilai Keluar");
         return 0;
     }
}
