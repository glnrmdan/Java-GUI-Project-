package dashboard;

import Login.Koneksi;
import java.awt.Color;
import java.awt.Font;
import java.sql.Connection;
import java.sql.SQLException;
import javax.swing.JOptionPane;
import javax.swing.UIManager;
import org.jfree.chart.ChartFactory;
import org.jfree.chart.ChartPanel;
import org.jfree.chart.JFreeChart;
import org.jfree.chart.plot.PiePlot3D;
import org.jfree.data.general.DefaultPieDataset;
import org.jfree.data.general.PieDataset;
import org.jfree.util.Rotation;

public class Chart extends javax.swing.JPanel {

    private String title = "Grafik Laporan";
    PieDataset dataset;
    JFreeChart chart;
    ChartPanel chartPanel;
    
    
    public Chart() {
        initComponents();
        createChart();
    }
    
    private void createChart(){
        dataset = createDataset();
        chart = createChart(dataset, title);
        chartPanel = new ChartPanel(chart);
        chartPanel.setSize(350, 482);
        this.add(chartPanel);
    }
    
    private  PieDataset createDataset() {
        
        DefaultPieDataset result = new DefaultPieDataset();
        
        int dataInvest = Chart.readIntInvest();
        result.setValue("Investasi", dataInvest);
        
        int dataTabung = Chart.readIntTabung();
        result.setValue("Tabungan", dataTabung);
        
        int dataDarurat = Chart.readIntDarurat();
        result.setValue("Dana Darurat", dataDarurat);
        return result;

    }
    
    // Data Untuk Nilai Investasi
    public static String readInvest() {
        String valueInvest = " ";
        try {
            String sql = "SELECT sum(tbTotal) as totalInvest from investasi";

            java.sql.Connection conn = (Connection) Koneksi.configDB();
            java.sql.Statement stm = conn.createStatement();
            java.sql.ResultSet rs = stm.executeQuery(sql);
            if (rs.next()) {
            valueInvest = rs.getString("totalInvest");
            }       
        } catch (SQLException e) {
            UIManager.put("OptionPane.messageFont", new Font("Tahoma", Font.BOLD, 16));
            JOptionPane.showMessageDialog(null, e);
        }
            return valueInvest;
    }
    public static int readIntInvest() {
        return Integer.parseInt(readInvest());
    }
    
    // Data Untuk Nilai Tabungan
    public static String readTabung() {
        String valueTabung = " ";
        try {
            String sql = "SELECT sum(tbTotal) as totalTabung from tabung";

            java.sql.Connection conn = (Connection) Koneksi.configDB();
            java.sql.Statement stm = conn.createStatement();
            java.sql.ResultSet rs = stm.executeQuery(sql);
            if (rs.next()) {
            valueTabung = rs.getString("totalTabung");
            }       
        } catch (SQLException e) {
            UIManager.put("OptionPane.messageFont", new Font("Tahoma", Font.BOLD, 16));
            JOptionPane.showMessageDialog(null, e);
        }
            return valueTabung;
    }
    public static int readIntTabung() {
        return Integer.parseInt(readTabung());
    }
    
    // Data Untuk Nilai Dana Darurat
    public static String readDarurat() {
        String valueDarurat = " ";
        try {
            String sql = "SELECT sum(tbTotal) as totalDarurat from danadarurat";

            java.sql.Connection conn = (Connection) Koneksi.configDB();
            java.sql.Statement stm = conn.createStatement();
            java.sql.ResultSet rs = stm.executeQuery(sql);
            if (rs.next()) {
            valueDarurat = rs.getString("totalDarurat");
            }       
        } catch (SQLException e) {
            UIManager.put("OptionPane.messageFont", new Font("Tahoma", Font.BOLD, 16));
            JOptionPane.showMessageDialog(null, e);
        }
            return valueDarurat;
    }
    public static int readIntDarurat() {
        return Integer.parseInt(readDarurat());
    }

    private JFreeChart createChart(PieDataset dataset, String title) {
        //Reference Variabel
        JFreeChart piePlot = ChartFactory.createPieChart3D(title, dataset, true, true, false);
        PiePlot3D plot = (PiePlot3D) piePlot.getPlot();
        /*
        Warna Tabung = Hijau [7,222,39]
        Warna Invest = Merah [239,7,7]
        Warna Darrat = Kuning Hijau [189,204,16]
        */
        plot.setSectionPaint("Tabungan", new Color(7,222,39));
        plot.setSectionPaint("Investasi", new Color(239,7,7));
        plot.setSectionPaint("Dana Darurat", new Color(189,204,16));
        //[9,161,161]
        plot.setBackgroundPaint(new Color(10, 180, 180));
        plot.setStartAngle(290);
        plot.setDirection(Rotation.CLOCKWISE);
        plot.setForegroundAlpha(0.5f);
        return piePlot;
    }
    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        setLayout(new java.awt.BorderLayout());
    }// </editor-fold>//GEN-END:initComponents
   
    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    // End of variables declaration//GEN-END:variables
}
