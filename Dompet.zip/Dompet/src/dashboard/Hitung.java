package dashboard;

public class Hitung extends Penampungan {
    
    public Hitung() {
        
    }
    Penampungan pen = new Penampungan();
    
    @Override
    int masuk() {
        int mas = pen.getMasuk();
        super.setMasuk(mas);
        return mas;
    }
    
    @Override
    int keluar() {
        int kel = pen.getKeluar();
        super.setKeluar(kel);
        return kel;
    }
    
    @Override
    int hitung() {
        //        int masuk = pen.getMasuk();
//        int keluar = pen.getKeluar();
        super.total = masuk() - keluar();
        super.setTotal(total);
        
        return total;
    }
        
    public int readHitung() {
        return hitung();
    }
}
