/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dashboard;

/**
 *
 * @author glnrmdan
 */
abstract class Abstrak {
    abstract int hitung();
    abstract int masuk();
    abstract int keluar();
    
    int hitung;
    int masuk;
    int keluar;
    int total;
}
