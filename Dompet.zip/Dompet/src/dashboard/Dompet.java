package dashboard;

import DanaDarurat.DanaDarurat;
import Investasi.Investasi;
import Tabungan.Tabungan;
import Login.Login;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import javax.swing.JFrame;

/**
 *
 * @author glnrmdan
 */
public class Dompet extends javax.swing.JFrame {
    Connection con = null;
    PreparedStatement pst = null;
    ResultSet ts = null;
    
    public Dompet() {
        initComponents();
//        TampilUser();
        this.setLocationRelativeTo(null); //agar objek berada di tengah
    }
    
    public Dompet (String user) {
        initComponents();
        this.setLocationRelativeTo(null);
        TextUser.setText(user);
    }
    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel4 = new javax.swing.JPanel();
        TextUser = new javax.swing.JTextField();
        jLabel1 = new javax.swing.JLabel();
        btTabung = new javax.swing.JTextField();
        logoTabung1 = new javax.swing.JLabel();
        chart2 = new dashboard.Chart();
        logoDanaDarurat = new javax.swing.JLabel();
        logoInvest = new javax.swing.JLabel();
        btInvest = new javax.swing.JTextField();
        btDanaDarurat = new javax.swing.JTextField();
        jPanel1 = new javax.swing.JPanel();
        jLabelClose1 = new javax.swing.JLabel();
        jLabelMin1 = new javax.swing.JLabel();
        jLabelMin = new javax.swing.JLabel();
        jPanel3 = new javax.swing.JPanel();
        jLabel2 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jPanel2 = new javax.swing.JPanel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setBackground(new java.awt.Color(255, 255, 255));
        setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));
        setUndecorated(true);

        jPanel4.setBackground(new java.awt.Color(0, 153, 153));
        jPanel4.setForeground(new java.awt.Color(255, 255, 255));

        TextUser.setEditable(false);
        TextUser.setBackground(new java.awt.Color(0, 102, 102));
        TextUser.setFont(new java.awt.Font("Dialog", 0, 24)); // NOI18N
        TextUser.setForeground(new java.awt.Color(255, 255, 255));
        TextUser.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        TextUser.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                TextUserActionPerformed(evt);
            }
        });

        jLabel1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Gambar/logout.png"))); // NOI18N
        jLabel1.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jLabel1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jLabel1MouseClicked(evt);
            }
        });

        btTabung.setEditable(false);
        btTabung.setBackground(new java.awt.Color(0, 102, 102));
        btTabung.setFont(new java.awt.Font("Tw Cen MT", 1, 40)); // NOI18N
        btTabung.setForeground(new java.awt.Color(255, 255, 255));
        btTabung.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        btTabung.setText("TABUNG");
        btTabung.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        btTabung.setDisabledTextColor(new java.awt.Color(51, 153, 0));
        btTabung.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                btTabungMouseClicked(evt);
            }
        });
        btTabung.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btTabungActionPerformed(evt);
            }
        });

        logoTabung1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/dashboard/tbg.png"))); // NOI18N
        logoTabung1.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        logoTabung1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                logoTabung1MouseClicked(evt);
            }
        });

        logoDanaDarurat.setIcon(new javax.swing.ImageIcon(getClass().getResource("/DanaDarurat/icons8_money_bag_96px_1.png"))); // NOI18N
        logoDanaDarurat.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        logoDanaDarurat.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                logoDanaDaruratMouseClicked(evt);
            }
        });

        logoInvest.setIcon(new javax.swing.ImageIcon(getClass().getResource("/dashboard/inv.png"))); // NOI18N
        logoInvest.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        logoInvest.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                logoInvestMouseClicked(evt);
            }
        });

        btInvest.setEditable(false);
        btInvest.setBackground(new java.awt.Color(0, 102, 102));
        btInvest.setFont(new java.awt.Font("Tw Cen MT", 1, 40)); // NOI18N
        btInvest.setForeground(new java.awt.Color(255, 255, 255));
        btInvest.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        btInvest.setText("INVESTASI");
        btInvest.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        btInvest.setDisabledTextColor(new java.awt.Color(51, 153, 0));
        btInvest.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                btInvestMouseClicked(evt);
            }
        });
        btInvest.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btInvestActionPerformed(evt);
            }
        });

        btDanaDarurat.setEditable(false);
        btDanaDarurat.setBackground(new java.awt.Color(0, 102, 102));
        btDanaDarurat.setFont(new java.awt.Font("Tw Cen MT", 1, 40)); // NOI18N
        btDanaDarurat.setForeground(new java.awt.Color(255, 255, 255));
        btDanaDarurat.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        btDanaDarurat.setText("DANA DARURAT");
        btDanaDarurat.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        btDanaDarurat.setDisabledTextColor(new java.awt.Color(51, 153, 0));
        btDanaDarurat.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                btDanaDaruratMouseClicked(evt);
            }
        });
        btDanaDarurat.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btDanaDaruratActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel4Layout = new javax.swing.GroupLayout(jPanel4);
        jPanel4.setLayout(jPanel4Layout);
        jPanel4Layout.setHorizontalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel4Layout.createSequentialGroup()
                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel4Layout.createSequentialGroup()
                        .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(TextUser, javax.swing.GroupLayout.PREFERRED_SIZE, 190, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jLabel1))
                    .addGroup(jPanel4Layout.createSequentialGroup()
                        .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel4Layout.createSequentialGroup()
                                .addContainerGap()
                                .addComponent(btDanaDarurat, javax.swing.GroupLayout.PREFERRED_SIZE, 307, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(jPanel4Layout.createSequentialGroup()
                                .addGap(115, 115, 115)
                                .addComponent(logoDanaDarurat))
                            .addGroup(jPanel4Layout.createSequentialGroup()
                                .addGap(116, 116, 116)
                                .addComponent(logoInvest))
                            .addGroup(jPanel4Layout.createSequentialGroup()
                                .addGap(66, 66, 66)
                                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(btInvest, javax.swing.GroupLayout.PREFERRED_SIZE, 199, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addGroup(jPanel4Layout.createSequentialGroup()
                                        .addGap(10, 10, 10)
                                        .addComponent(btTabung, javax.swing.GroupLayout.PREFERRED_SIZE, 178, javax.swing.GroupLayout.PREFERRED_SIZE))))
                            .addGroup(jPanel4Layout.createSequentialGroup()
                                .addGap(116, 116, 116)
                                .addComponent(logoTabung1)))
                        .addGap(18, 18, 18)
                        .addComponent(chart2, javax.swing.GroupLayout.PREFERRED_SIZE, 736, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(0, 24, Short.MAX_VALUE)))
                .addContainerGap())
        );
        jPanel4Layout.setVerticalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel4Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(jLabel1)
                    .addComponent(TextUser, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel4Layout.createSequentialGroup()
                        .addGap(12, 12, 12)
                        .addComponent(logoTabung1)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(btTabung, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(23, 23, 23)
                        .addComponent(logoInvest)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(btInvest, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(logoDanaDarurat)
                        .addGap(8, 8, 8)
                        .addComponent(btDanaDarurat, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel4Layout.createSequentialGroup()
                        .addGap(18, 18, 18)
                        .addComponent(chart2, javax.swing.GroupLayout.PREFERRED_SIZE, 503, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(97, Short.MAX_VALUE))
        );

        jPanel1.setBackground(new java.awt.Color(255, 255, 255));
        jPanel1.setForeground(new java.awt.Color(255, 255, 255));

        jLabelClose1.setBackground(new java.awt.Color(255, 0, 0));
        jLabelClose1.setFont(new java.awt.Font("Tahoma", 1, 30)); // NOI18N
        jLabelClose1.setForeground(new java.awt.Color(255, 0, 0));
        jLabelClose1.setText("X");
        jLabelClose1.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jLabelClose1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jLabelClose1MouseClicked(evt);
            }
        });

        jLabelMin1.setBackground(new java.awt.Color(0, 204, 204));
        jLabelMin1.setFont(new java.awt.Font("Tahoma", 1, 48)); // NOI18N
        jLabelMin1.setForeground(new java.awt.Color(0, 204, 204));
        jLabelMin1.setText("-");
        jLabelMin1.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jLabelMin1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jLabelMin1MouseClicked(evt);
            }
        });

        jLabelMin.setFont(new java.awt.Font("Tahoma", 1, 48)); // NOI18N
        jLabelMin.setForeground(new java.awt.Color(0, 204, 204));
        jLabelMin.setText("-");
        jLabelMin.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jLabelMin.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jLabelMinMouseClicked(evt);
            }
        });

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabelMin1, javax.swing.GroupLayout.PREFERRED_SIZE, 29, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabelMin))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabelClose1)
                .addGap(10, 10, 10))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jLabelClose1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addComponent(jLabelMin1, javax.swing.GroupLayout.PREFERRED_SIZE, 0, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabelMin, javax.swing.GroupLayout.PREFERRED_SIZE, 20, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, Short.MAX_VALUE))
        );

        jPanel3.setBackground(new java.awt.Color(0, 102, 102));
        jPanel3.setForeground(new java.awt.Color(255, 255, 255));
        jPanel3.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel2.setFont(new java.awt.Font("Tahoma", 1, 36)); // NOI18N
        jLabel2.setForeground(new java.awt.Color(255, 255, 255));
        jLabel2.setText("DompetKu");
        jPanel3.add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 30, -1, -1));

        jLabel4.setFont(new java.awt.Font("Tahoma", 1, 48)); // NOI18N
        jLabel4.setForeground(new java.awt.Color(255, 255, 255));
        jLabel4.setText("________");
        jPanel3.add(jLabel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 30, -1, 60));

        jPanel2.setBackground(new java.awt.Color(222, 222, 222));
        jPanel2.setForeground(new java.awt.Color(255, 255, 255));
        jPanel2.setPreferredSize(new java.awt.Dimension(0, 6));

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 0, Short.MAX_VALUE)
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 11, Short.MAX_VALUE)
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addComponent(jPanel2, javax.swing.GroupLayout.DEFAULT_SIZE, 1394, Short.MAX_VALUE)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jPanel3, javax.swing.GroupLayout.PREFERRED_SIZE, 273, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jPanel4, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, Short.MAX_VALUE)
                .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, 11, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, 0)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(jPanel4, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jPanel3, javax.swing.GroupLayout.DEFAULT_SIZE, 674, Short.MAX_VALUE))
                .addContainerGap())
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void jLabelMin1MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabelMin1MouseClicked
        this.setState(JFrame.ICONIFIED);
    }//GEN-LAST:event_jLabelMin1MouseClicked

    private void jLabelClose1MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabelClose1MouseClicked

        System.exit(0);
    }//GEN-LAST:event_jLabelClose1MouseClicked

    private void jLabelMinMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabelMinMouseClicked
        this.setState(JFrame.ICONIFIED);
    }//GEN-LAST:event_jLabelMinMouseClicked

    private void jLabel1MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel1MouseClicked
        Dompet dmp = new Dompet();
        dmp.setVisible(false);
        Login lg = new Login();  //FUNGSINYA UNTUK LOGOUT DARI KASIR KE LOGIN FORM
        lg.setVisible(true);
        lg.pack();
        lg.setLocationRelativeTo(null);
        lg.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
//        this.setVisible(false);
//        rs.close;
        this.dispose();
    }//GEN-LAST:event_jLabel1MouseClicked
    

    private void TextUserActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_TextUserActionPerformed
        
    }//GEN-LAST:event_TextUserActionPerformed

    
    private void btTabungActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btTabungActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_btTabungActionPerformed

    private void btTabungMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btTabungMouseClicked
        Dompet dmp = new Dompet();
        dmp.setVisible(false);
        String user = TextUser.getText();
        Tabungan tb = new Tabungan(user);
        
//        Tabungan tb = new Tabungan();  //FUNGSINYA UNTUK LOGOUT DARI KASIR KE LOGIN FORM
        tb.setVisible(true);
        tb.pack();
        tb.setLocationRelativeTo(null);
        tb.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
//        this.setVisible(false);
        this.dispose();
    }//GEN-LAST:event_btTabungMouseClicked

    private void logoInvestMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_logoInvestMouseClicked
        Dompet dmp = new Dompet();
        dmp.setVisible(false);
        String user = TextUser.getText();
        Investasi iv = new Investasi(user);
        
        //FUNGSINYA UNTUK LOGOUT DARI KASIR KE LOGIN FORM
        iv.setVisible(true);
        iv.pack();
        iv.setLocationRelativeTo(null);
        iv.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        this.dispose();
    }//GEN-LAST:event_logoInvestMouseClicked

    private void logoTabung1MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_logoTabung1MouseClicked
        Dompet dmp = new Dompet();
        dmp.setVisible(false);
        String user = TextUser.getText();
        Tabungan tb = new Tabungan(user);
        
//        Tabungan tb = new Tabungan();  //FUNGSINYA UNTUK LOGOUT DARI KASIR KE LOGIN FORM
        tb.setVisible(true);
        tb.pack();
        tb.setLocationRelativeTo(null);
        tb.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        this.dispose();
    }//GEN-LAST:event_logoTabung1MouseClicked

    private void btInvestMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btInvestMouseClicked
        Dompet dmp = new Dompet();
        dmp.setVisible(false);
        String user = TextUser.getText();
        Investasi iv = new Investasi(user);
        
        //FUNGSINYA UNTUK LOGOUT DARI KASIR KE LOGIN FORM
        iv.setVisible(true);
        iv.pack();
        iv.setLocationRelativeTo(null);
        iv.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
//        this.setVisible(false);
        this.dispose();
    }//GEN-LAST:event_btInvestMouseClicked

    private void btInvestActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btInvestActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_btInvestActionPerformed

    private void logoDanaDaruratMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_logoDanaDaruratMouseClicked
        Dompet dmp = new Dompet();
        dmp.setVisible(false);
        String user = TextUser.getText();
        DanaDarurat dd = new DanaDarurat(user);
        
        dd.setVisible(true);
        dd.pack();
        dd.setLocationRelativeTo(null);
        dd.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        this.dispose();
    }//GEN-LAST:event_logoDanaDaruratMouseClicked

    private void btDanaDaruratMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btDanaDaruratMouseClicked
        Dompet dmp = new Dompet();
        dmp.setVisible(false);
        String user = TextUser.getText();
        DanaDarurat dd = new DanaDarurat(user);
        
        dd.setVisible(true);
        dd.pack();
        dd.setLocationRelativeTo(null);
        dd.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        this.dispose();
    }//GEN-LAST:event_btDanaDaruratMouseClicked

    private void btDanaDaruratActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btDanaDaruratActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_btDanaDaruratActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException | InstantiationException | IllegalAccessException | javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Dompet.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>    
        
        //</editor-fold>
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            @Override
            public void run() {
                new Dompet().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JTextField TextUser;
    private javax.swing.JTextField btDanaDarurat;
    private javax.swing.JTextField btInvest;
    private javax.swing.JTextField btTabung;
    private dashboard.Chart chart2;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabelClose1;
    private javax.swing.JLabel jLabelMin;
    private javax.swing.JLabel jLabelMin1;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JPanel jPanel4;
    private javax.swing.JLabel logoDanaDarurat;
    private javax.swing.JLabel logoInvest;
    private javax.swing.JLabel logoTabung1;
    // End of variables declaration//GEN-END:variables
}
