package Login;


import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;

public class Koneksi {
    
    private static Connection c;
    
    public static Connection configDB() throws SQLException{
        try {
            String url = "jdbc:mysql://localhost/dompet";
            String user = "root";
            String pass = "";
            
            DriverManager.registerDriver(new com.mysql.jdbc.Driver());
            c = (Connection) DriverManager.getConnection (url, user, pass);
    }catch (SQLException e) {
        System.err.println("Koneksi Database Gagal! " + e.getMessage());
    }
        return c;
}
    
    public static void setData(String s) throws Exception{
        Koneksi.configDB().createStatement().executeUpdate(s);
    }
    public static ResultSet getData(String sq) throws Exception{
        return Koneksi.configDB().createStatement().executeQuery(sq);
    }
}