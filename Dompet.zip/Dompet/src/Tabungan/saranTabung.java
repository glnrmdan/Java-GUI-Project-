package Tabungan;

import java.awt.Component;
import javax.swing.JTable;
import javax.swing.JTextArea;
import javax.swing.table.TableCellRenderer;

/**
 *
 * @author glnrmdan
 */
public class saranTabung extends javax.swing.JFrame {
    
    public saranTabung() {
        initComponents();
        this.setLocationRelativeTo(null);
    }

    class WordWrapCellRenderer extends JTextArea implements TableCellRenderer
    {
        WordWrapCellRenderer()
        {
            setLineWrap(true);
            setWrapStyleWord(true);
        }
        
        @Override
        public Component getTableCellRendererComponent(JTable table, Object value,
                boolean isSelected, boolean hasFocus, int row, int column)
        {
            setText(value.toString());
            setSize(table.getColumnModel().getColumn(column).getWidth(),
                    getPreferredSize().height);
            if (table.getRowHeight(row) != getPreferredSize().height)
            {
                table.setRowHeight(row, getPreferredSize().height);
            }
            return this;
        }
    }
    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        SaranTabung = new javax.swing.JTabbedPane();
        st2 = new javax.swing.JPanel();
        jTextField2 = new javax.swing.JTextField();
        jScrollPane1 = new javax.swing.JScrollPane();
        jTextArea1 = new javax.swing.JTextArea();
        btNext1 = new javax.swing.JLabel();
        btClose1 = new javax.swing.JLabel();
        st3 = new javax.swing.JPanel();
        jTextField3 = new javax.swing.JTextField();
        jScrollPane3 = new javax.swing.JScrollPane();
        jTextArea3 = new javax.swing.JTextArea();
        btNext2 = new javax.swing.JLabel();
        btPrev1 = new javax.swing.JLabel();
        btClose2 = new javax.swing.JLabel();
        st4 = new javax.swing.JPanel();
        jTextField4 = new javax.swing.JTextField();
        jScrollPane4 = new javax.swing.JScrollPane();
        jTextArea4 = new javax.swing.JTextArea();
        btPrev2 = new javax.swing.JLabel();
        btNext3 = new javax.swing.JLabel();
        btClose3 = new javax.swing.JLabel();
        st5 = new javax.swing.JPanel();
        jTextField5 = new javax.swing.JTextField();
        jScrollPane5 = new javax.swing.JScrollPane();
        jTextArea5 = new javax.swing.JTextArea();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        btClose4 = new javax.swing.JLabel();
        jPanel1 = new javax.swing.JPanel();
        jTextField6 = new javax.swing.JTextField();
        jScrollPane6 = new javax.swing.JScrollPane();
        jTextArea6 = new javax.swing.JTextArea();
        btPrev4 = new javax.swing.JLabel();
        btClose5 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setBackground(new java.awt.Color(255, 255, 255));
        setUndecorated(true);
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        st2.setBackground(new java.awt.Color(0, 153, 153));
        st2.setPreferredSize(new java.awt.Dimension(612, 650));
        st2.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jTextField2.setEditable(false);
        jTextField2.setBackground(new java.awt.Color(0, 153, 153));
        jTextField2.setFont(new java.awt.Font("Ebrima", 1, 30)); // NOI18N
        jTextField2.setForeground(new java.awt.Color(255, 255, 255));
        jTextField2.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        jTextField2.setText("ATUR PEMASUKKAN > PENGELUARAN");
        jTextField2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jTextField2ActionPerformed(evt);
            }
        });
        st2.add(jTextField2, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 4, 612, 65));

        jTextArea1.setEditable(false);
        jTextArea1.setColumns(20);
        jTextArea1.setFont(new java.awt.Font("Nirmala UI", 0, 30)); // NOI18N
        jTextArea1.setForeground(new java.awt.Color(0, 153, 153));
        jTextArea1.setLineWrap(true);
        jTextArea1.setRows(5);
        jTextArea1.setText("Biasakanlah diri untuk menambah income dibandingkan dengan pengeluaran.\n\nSekarang ini banyak sekali bertebaran usaha Online yang dapat dimanfaatkan sebagai seorang freelancer, baik dibidang desain grafik, pemrogramman, digital marketing, atau bahkan membuat konsep konten instagram.\n\nLalu juga jangan lupa tahan dan kurangi pengeluaran uang dari dompetmu. Dengan begitu kamu akan semakin cepat mencapai tujuan finansialmu.");
        jTextArea1.setWrapStyleWord(true);
        jTextArea1.setLineWrap(true);
        jTextArea1.setWrapStyleWord(true);
        jScrollPane1.setViewportView(jTextArea1);

        st2.add(jScrollPane1, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 87, 592, 601));

        btNext1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Tabungan/icons8_right_64px.png"))); // NOI18N
        btNext1.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        btNext1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                btNext1MouseClicked(evt);
            }
        });
        st2.add(btNext1, new org.netbeans.lib.awtextra.AbsoluteConstraints(538, 694, -1, 59));

        btClose1.setBackground(new java.awt.Color(255, 255, 255));
        btClose1.setForeground(new java.awt.Color(255, 255, 255));
        btClose1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Tabungan/icons8_close_window_48px.png"))); // NOI18N
        btClose1.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        btClose1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                btClose1MouseClicked(evt);
            }
        });
        st2.add(btClose1, new org.netbeans.lib.awtextra.AbsoluteConstraints(280, 700, -1, -1));

        SaranTabung.addTab("S_1", st2);

        st3.setBackground(new java.awt.Color(0, 153, 153));
        st3.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jTextField3.setEditable(false);
        jTextField3.setBackground(new java.awt.Color(0, 153, 153));
        jTextField3.setFont(new java.awt.Font("Ebrima", 1, 36)); // NOI18N
        jTextField3.setForeground(new java.awt.Color(255, 255, 255));
        jTextField3.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        jTextField3.setText("BUAT PRIORITAS");
        st3.add(jTextField3, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 612, 65));

        jTextArea3.setEditable(false);
        jTextArea3.setColumns(20);
        jTextArea3.setFont(new java.awt.Font("Nirmala UI", 0, 30)); // NOI18N
        jTextArea3.setForeground(new java.awt.Color(0, 153, 153));
        jTextArea3.setLineWrap(true);
        jTextArea3.setRows(5);
        jTextArea3.setText("Buatlah urutan prioritas alokasi keuangan. Jika tujuanmu adalah menabung, maka prioritaskan pemasukkanmu untuk masuk kedalam tabungan.\n\nDengan adanya prioritas tersebut, maka secara tidak langsung kamu akan merasa bahwa hal-hal lain yang diluar prioritas tersebut akan mulai tertekan keluar dari daftar keinginanmu secara perlahan.");
        jTextArea3.setWrapStyleWord(true);
        jTextArea1.setLineWrap(true);
        jTextArea1.setWrapStyleWord(true);
        jScrollPane3.setViewportView(jTextArea3);

        st3.add(jScrollPane3, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 71, 592, 601));

        btNext2.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Tabungan/icons8_right_64px.png"))); // NOI18N
        btNext2.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        btNext2.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                btNext2MouseClicked(evt);
            }
        });
        st3.add(btNext2, new org.netbeans.lib.awtextra.AbsoluteConstraints(538, 678, -1, -1));

        btPrev1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Tabungan/icons8_left_64px.png"))); // NOI18N
        btPrev1.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        btPrev1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                btPrev1MouseClicked(evt);
            }
        });
        st3.add(btPrev1, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 678, -1, -1));

        btClose2.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Tabungan/icons8_close_window_48px.png"))); // NOI18N
        btClose2.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        btClose2.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                btClose2MouseClicked(evt);
            }
        });
        st3.add(btClose2, new org.netbeans.lib.awtextra.AbsoluteConstraints(280, 690, -1, -1));

        SaranTabung.addTab("S_2", st3);

        st4.setBackground(new java.awt.Color(0, 153, 153));
        st4.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jTextField4.setEditable(false);
        jTextField4.setBackground(new java.awt.Color(0, 153, 153));
        jTextField4.setFont(new java.awt.Font("Ebrima", 1, 36)); // NOI18N
        jTextField4.setForeground(new java.awt.Color(255, 255, 255));
        jTextField4.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        jTextField4.setText("KURANGI NONGKRONG");
        st4.add(jTextField4, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 612, 65));

        jTextArea4.setEditable(false);
        jTextArea4.setColumns(20);
        jTextArea4.setFont(new java.awt.Font("Nirmala UI", 0, 30)); // NOI18N
        jTextArea4.setForeground(new java.awt.Color(0, 153, 153));
        jTextArea4.setLineWrap(true);
        jTextArea4.setRows(5);
        jTextArea4.setText("Sudah sangat wajar bagi anak muda saat ini untuk selalu nongkrong dan terlihat gaul diantara sesamanya.\n\nTapi sadarkah kamu jika hal itu dapat memicu pemborosan uangmu secara signifikan ?\n\nMisalkan sekali kita nongkrong keluar sepuluh ribu, dan dalam satu bulan kita nongkrong kurang lebih sebanyak delapan kali. Maka dalam satu bulan tersebut kamu telah mengeluarkan uang delapan puluh ribu yang seharusnya bisa kamu tabung.");
        jTextArea4.setWrapStyleWord(true);
        jTextArea1.setLineWrap(true);
        jTextArea1.setWrapStyleWord(true);
        jScrollPane4.setViewportView(jTextArea4);

        st4.add(jScrollPane4, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 71, 592, 601));

        btPrev2.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Tabungan/icons8_left_64px.png"))); // NOI18N
        btPrev2.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        btPrev2.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                btPrev2MouseClicked(evt);
            }
        });
        st4.add(btPrev2, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 678, -1, -1));

        btNext3.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Tabungan/icons8_right_64px.png"))); // NOI18N
        btNext3.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        btNext3.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                btNext3MouseClicked(evt);
            }
        });
        st4.add(btNext3, new org.netbeans.lib.awtextra.AbsoluteConstraints(538, 678, -1, -1));

        btClose3.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Tabungan/icons8_close_window_48px.png"))); // NOI18N
        btClose3.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        btClose3.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                btClose3MouseClicked(evt);
            }
        });
        st4.add(btClose3, new org.netbeans.lib.awtextra.AbsoluteConstraints(280, 690, -1, -1));

        SaranTabung.addTab("S_3", st4);

        st5.setBackground(new java.awt.Color(0, 153, 153));
        st5.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jTextField5.setEditable(false);
        jTextField5.setBackground(new java.awt.Color(0, 153, 153));
        jTextField5.setFont(new java.awt.Font("Ebrima", 1, 32)); // NOI18N
        jTextField5.setForeground(new java.awt.Color(255, 255, 255));
        jTextField5.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        jTextField5.setText("MAKAN MINUM BAWA SENDIRI");
        st5.add(jTextField5, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 612, 65));

        jTextArea5.setEditable(false);
        jTextArea5.setColumns(20);
        jTextArea5.setFont(new java.awt.Font("Nirmala UI", 0, 30)); // NOI18N
        jTextArea5.setForeground(new java.awt.Color(0, 153, 153));
        jTextArea5.setLineWrap(true);
        jTextArea5.setRows(5);
        jTextArea5.setText("Kebutuhan primer yang satu ini memang sangatlah menggoda untuk selalu dituruti.\n\nKetika kamu sedang jalan-jalan atau bersekolah dan saat itu juga kamu lapar atau haus, pastilah kamu akan mencari kedai terdekat untuk memebuhi hal itu.\n\nMaka solusi paling tepat untuk menekan pengeluaran kecil-kecil namun konstan ini adalah dengan membawa bekal dan minum sendiri dari rumah.");
        jTextArea5.setWrapStyleWord(true);
        jTextArea1.setLineWrap(true);
        jTextArea1.setWrapStyleWord(true);
        jScrollPane5.setViewportView(jTextArea5);

        st5.add(jScrollPane5, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 71, 592, 601));

        jLabel1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Tabungan/icons8_left_64px.png"))); // NOI18N
        jLabel1.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jLabel1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jLabel1MouseClicked(evt);
            }
        });
        st5.add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 678, -1, -1));

        jLabel2.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Tabungan/icons8_right_64px.png"))); // NOI18N
        jLabel2.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jLabel2.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jLabel2MouseClicked(evt);
            }
        });
        st5.add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(538, 678, -1, -1));

        btClose4.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Tabungan/icons8_close_window_48px.png"))); // NOI18N
        btClose4.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        btClose4.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                btClose4MouseClicked(evt);
            }
        });
        st5.add(btClose4, new org.netbeans.lib.awtextra.AbsoluteConstraints(280, 690, -1, -1));

        SaranTabung.addTab("S_4", st5);

        jPanel1.setBackground(new java.awt.Color(0, 153, 153));
        jPanel1.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jTextField6.setEditable(false);
        jTextField6.setBackground(new java.awt.Color(0, 153, 153));
        jTextField6.setFont(new java.awt.Font("Ebrima", 1, 32)); // NOI18N
        jTextField6.setForeground(new java.awt.Color(255, 255, 255));
        jTextField6.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        jTextField6.setText("SIMPAN UANG RECEH");
        jTextField6.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jTextField6ActionPerformed(evt);
            }
        });
        jPanel1.add(jTextField6, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 612, 65));

        jTextArea6.setEditable(false);
        jTextArea6.setColumns(20);
        jTextArea6.setFont(new java.awt.Font("Nirmala UI", 0, 30)); // NOI18N
        jTextArea6.setForeground(new java.awt.Color(0, 153, 153));
        jTextArea6.setLineWrap(true);
        jTextArea6.setRows(5);
        jTextArea6.setText("Disadari atau tidak, kita seringkali anggap remeh nominal kecil dari uang receh atau uang koin. Padahal jika kita mengumpulkan uang receh ini bisa saja nominalnya menjadi besar.\n\nUang receh yang sering kita remehkan hingga hilang keberadaannya seharusnya bisa menjadi bagian dari tabungan kita saat ini atau bisa saja kita jadikan sebagai uang parkir.\n\nKarena sering kali kita remehkan mungkin saja jika kita kumpulkan sedari dulu nominalnya sudah besar.");
        jTextArea6.setWrapStyleWord(true);
        jTextArea1.setLineWrap(true);
        jTextArea1.setWrapStyleWord(true);
        jScrollPane6.setViewportView(jTextArea6);

        jPanel1.add(jScrollPane6, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 71, 592, 640));

        btPrev4.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Tabungan/icons8_left_64px.png"))); // NOI18N
        btPrev4.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        btPrev4.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                btPrev4MouseClicked(evt);
            }
        });
        jPanel1.add(btPrev4, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 709, -1, -1));

        btClose5.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Tabungan/icons8_close_window_48px.png"))); // NOI18N
        btClose5.setToolTipText("");
        btClose5.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        btClose5.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                btClose5MouseClicked(evt);
            }
        });
        jPanel1.add(btClose5, new org.netbeans.lib.awtextra.AbsoluteConstraints(280, 720, -1, -1));

        SaranTabung.addTab("S_5", jPanel1);

        getContentPane().add(SaranTabung, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, -32, 615, 830));

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void jTextField2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTextField2ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jTextField2ActionPerformed

    private void btNext1MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btNext1MouseClicked
        SaranTabung.setSelectedIndex(1);
    }//GEN-LAST:event_btNext1MouseClicked

    private void btNext2MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btNext2MouseClicked
        SaranTabung.setSelectedIndex(2);
    }//GEN-LAST:event_btNext2MouseClicked

    private void btPrev1MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btPrev1MouseClicked
        SaranTabung.setSelectedIndex(0);
    }//GEN-LAST:event_btPrev1MouseClicked

    private void btPrev2MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btPrev2MouseClicked
        SaranTabung.setSelectedIndex(1);
    }//GEN-LAST:event_btPrev2MouseClicked

    private void btNext3MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btNext3MouseClicked
        SaranTabung.setSelectedIndex(3);
    }//GEN-LAST:event_btNext3MouseClicked

    private void jLabel1MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel1MouseClicked
        SaranTabung.setSelectedIndex(2);
    }//GEN-LAST:event_jLabel1MouseClicked

    private void jLabel2MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel2MouseClicked
        SaranTabung.setSelectedIndex(4);
    }//GEN-LAST:event_jLabel2MouseClicked

    private void jTextField6ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTextField6ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jTextField6ActionPerformed

    private void btPrev4MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btPrev4MouseClicked
        SaranTabung.setSelectedIndex(3);
    }//GEN-LAST:event_btPrev4MouseClicked

    private void btClose1MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btClose1MouseClicked
        this.dispose();
    }//GEN-LAST:event_btClose1MouseClicked

    private void btClose2MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btClose2MouseClicked
        this.dispose();
    }//GEN-LAST:event_btClose2MouseClicked

    private void btClose3MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btClose3MouseClicked
        this.dispose();
    }//GEN-LAST:event_btClose3MouseClicked

    private void btClose4MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btClose4MouseClicked
        this.dispose();
    }//GEN-LAST:event_btClose4MouseClicked

    private void btClose5MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btClose5MouseClicked
        this.dispose();
    }//GEN-LAST:event_btClose5MouseClicked

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(saranTabung.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(saranTabung.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(saranTabung.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(saranTabung.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new saranTabung().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JTabbedPane SaranTabung;
    private javax.swing.JLabel btClose1;
    private javax.swing.JLabel btClose2;
    private javax.swing.JLabel btClose3;
    private javax.swing.JLabel btClose4;
    private javax.swing.JLabel btClose5;
    private javax.swing.JLabel btNext1;
    private javax.swing.JLabel btNext2;
    private javax.swing.JLabel btNext3;
    private javax.swing.JLabel btPrev1;
    private javax.swing.JLabel btPrev2;
    private javax.swing.JLabel btPrev4;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane3;
    private javax.swing.JScrollPane jScrollPane4;
    private javax.swing.JScrollPane jScrollPane5;
    private javax.swing.JScrollPane jScrollPane6;
    private javax.swing.JTextArea jTextArea1;
    private javax.swing.JTextArea jTextArea3;
    private javax.swing.JTextArea jTextArea4;
    private javax.swing.JTextArea jTextArea5;
    private javax.swing.JTextArea jTextArea6;
    private javax.swing.JTextField jTextField2;
    private javax.swing.JTextField jTextField3;
    private javax.swing.JTextField jTextField4;
    private javax.swing.JTextField jTextField5;
    private javax.swing.JTextField jTextField6;
    private javax.swing.JPanel st2;
    private javax.swing.JPanel st3;
    private javax.swing.JPanel st4;
    private javax.swing.JPanel st5;
    // End of variables declaration//GEN-END:variables
}
