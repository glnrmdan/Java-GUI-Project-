package Investasi;

import Login.Koneksi;
import dashboard.Dompet;
import dashboard.Penampungan;
import java.awt.Color;
import java.awt.Font;
import java.awt.HeadlessException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.UIManager;
import java.util.Calendar;
import javax.swing.table.DefaultTableModel;
/**
 *
 * @author glnrmdan
 */
public class Investasi extends javax.swing.JFrame {
    Connection con = null;
    PreparedStatement pst = null;
    ResultSet ts = null;
    
    public Investasi() {
        initComponents();
        setDefault();
        tampilInvest();
        this.setLocationRelativeTo(null);
        
        tbLaporInvest.getTableHeader().setFont(new Font("Trebuchet MS", Font.BOLD, 18));
        tbLaporInvest.getTableHeader().setOpaque(false);
        tbLaporInvest.getTableHeader().setBackground(new Color(32, 136, 203));
        tbLaporInvest.getTableHeader().setForeground(new Color(0,102,0));
        tbLaporInvest.setRowHeight(25);
    }

    public Investasi (String user) {
        initComponents();
        this.setLocationRelativeTo(null);
        TextUser.setText(user);
    }
    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jPanel3 = new javax.swing.JPanel();
        jLabel3 = new javax.swing.JLabel();
        txtMasuk = new javax.swing.JTextField();
        sM = new javax.swing.JButton();
        limaK = new javax.swing.JButton();
        satuK = new javax.swing.JButton();
        limaM = new javax.swing.JButton();
        sepM = new javax.swing.JButton();
        limaPulM = new javax.swing.JButton();
        jPanel12 = new javax.swing.JPanel();
        jLabel5 = new javax.swing.JLabel();
        jPanel4 = new javax.swing.JPanel();
        jLabelClose1 = new javax.swing.JLabel();
        jLabelMin1 = new javax.swing.JLabel();
        jLabelMin2 = new javax.swing.JLabel();
        jPanel5 = new javax.swing.JPanel();
        jPanel6 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        txtKeluar = new javax.swing.JTextField();
        inKel1M = new javax.swing.JButton();
        inKel5K = new javax.swing.JButton();
        inKel1K = new javax.swing.JButton();
        limaPulMOut = new javax.swing.JButton();
        sepMOut = new javax.swing.JButton();
        limaMOut = new javax.swing.JButton();
        jPanel13 = new javax.swing.JPanel();
        jLabel6 = new javax.swing.JLabel();
        jPanel10 = new javax.swing.JPanel();
        jPanel14 = new javax.swing.JPanel();
        jLabel7 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        txtTotal = new javax.swing.JTextField();
        btHitung = new javax.swing.JButton();
        jPanel2 = new javax.swing.JPanel();
        jPanel11 = new javax.swing.JPanel();
        jLabel4 = new javax.swing.JLabel();
        jScrollPane1 = new javax.swing.JScrollPane();
        tbLaporInvest = new javax.swing.JTable();
        jPanel9 = new javax.swing.JPanel();
        jPanel16 = new javax.swing.JPanel();
        TextUser = new javax.swing.JTextField();
        jPanel15 = new javax.swing.JPanel();
        jPanel17 = new javax.swing.JPanel();
        jPanel18 = new javax.swing.JPanel();
        jPanel7 = new javax.swing.JPanel();
        btInput = new javax.swing.JButton();
        jButton1 = new javax.swing.JButton();
        btRefreshinv = new javax.swing.JButton();
        jTextField1 = new javax.swing.JTextField();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setUndecorated(true);

        jPanel1.setBackground(new java.awt.Color(206, 49, 26));

        jPanel3.setBackground(new java.awt.Color(244, 244, 244));

        jLabel3.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Investasi/icons8_cheap_2_96px_2.png"))); // NOI18N

        txtMasuk.setFont(new java.awt.Font("Ebrima", 1, 30)); // NOI18N
        txtMasuk.setForeground(new java.awt.Color(153, 0, 0));
        txtMasuk.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        txtMasuk.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtMasukActionPerformed(evt);
            }
        });

        sM.setBackground(new java.awt.Color(127, 19, 19));
        sM.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        sM.setForeground(new java.awt.Color(255, 255, 255));
        sM.setText("1M");
        sM.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                sMMouseClicked(evt);
            }
        });

        limaK.setBackground(new java.awt.Color(127, 19, 19));
        limaK.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        limaK.setForeground(new java.awt.Color(255, 255, 255));
        limaK.setText("500K");
        limaK.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                limaKMouseClicked(evt);
            }
        });

        satuK.setBackground(new java.awt.Color(127, 19, 19));
        satuK.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        satuK.setForeground(new java.awt.Color(255, 255, 255));
        satuK.setText("100K");
        satuK.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                satuKMouseClicked(evt);
            }
        });

        limaM.setBackground(new java.awt.Color(127, 19, 19));
        limaM.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        limaM.setForeground(new java.awt.Color(255, 255, 255));
        limaM.setText("5M");
        limaM.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                limaMMouseClicked(evt);
            }
        });

        sepM.setBackground(new java.awt.Color(127, 19, 19));
        sepM.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        sepM.setForeground(new java.awt.Color(255, 255, 255));
        sepM.setText("10M");
        sepM.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                sepMMouseClicked(evt);
            }
        });

        limaPulM.setBackground(new java.awt.Color(127, 19, 19));
        limaPulM.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        limaPulM.setForeground(new java.awt.Color(255, 255, 255));
        limaPulM.setText("50M");
        limaPulM.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                limaPulMMouseClicked(evt);
            }
        });
        limaPulM.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                limaPulMActionPerformed(evt);
            }
        });

        jPanel12.setBackground(new java.awt.Color(204, 0, 51));

        jLabel5.setFont(new java.awt.Font("Ebrima", 1, 24)); // NOI18N
        jLabel5.setForeground(new java.awt.Color(255, 255, 255));
        jLabel5.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel5.setText("TOTAL PEMASUKKAN");

        javax.swing.GroupLayout jPanel12Layout = new javax.swing.GroupLayout(jPanel12);
        jPanel12.setLayout(jPanel12Layout);
        jPanel12Layout.setHorizontalGroup(
            jPanel12Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jLabel5, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        jPanel12Layout.setVerticalGroup(
            jPanel12Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jLabel5, javax.swing.GroupLayout.DEFAULT_SIZE, 80, Short.MAX_VALUE)
        );

        javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
        jPanel3.setLayout(jPanel3Layout);
        jPanel3Layout.setHorizontalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addGap(27, 27, 27)
                .addComponent(jLabel3)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                    .addGroup(javax.swing.GroupLayout.Alignment.LEADING, jPanel3Layout.createSequentialGroup()
                        .addComponent(sM)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(limaK)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(satuK))
                    .addComponent(txtMasuk, javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addComponent(limaPulM, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(sepM, javax.swing.GroupLayout.PREFERRED_SIZE, 66, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(limaM)))
                .addContainerGap(19, Short.MAX_VALUE))
            .addComponent(jPanel12, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        jPanel3Layout.setVerticalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addComponent(jPanel12, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 28, Short.MAX_VALUE)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel3Layout.createSequentialGroup()
                        .addComponent(jLabel3)
                        .addGap(34, 34, 34))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel3Layout.createSequentialGroup()
                        .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(limaM)
                            .addComponent(sepM)
                            .addComponent(limaPulM))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(txtMasuk, javax.swing.GroupLayout.PREFERRED_SIZE, 44, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(sM)
                            .addComponent(limaK)
                            .addComponent(satuK))
                        .addGap(15, 15, 15))))
        );

        jPanel4.setBackground(new java.awt.Color(255, 255, 255));
        jPanel4.setForeground(new java.awt.Color(255, 255, 255));

        jLabelClose1.setBackground(new java.awt.Color(255, 0, 0));
        jLabelClose1.setFont(new java.awt.Font("Tahoma", 1, 30)); // NOI18N
        jLabelClose1.setForeground(new java.awt.Color(255, 0, 0));
        jLabelClose1.setText("X");
        jLabelClose1.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jLabelClose1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jLabelClose1MouseClicked(evt);
            }
        });

        jLabelMin1.setBackground(new java.awt.Color(0, 204, 204));
        jLabelMin1.setFont(new java.awt.Font("Tahoma", 1, 48)); // NOI18N
        jLabelMin1.setForeground(new java.awt.Color(0, 204, 204));
        jLabelMin1.setText("-");
        jLabelMin1.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jLabelMin1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jLabelMin1MouseClicked(evt);
            }
        });

        jLabelMin2.setFont(new java.awt.Font("Tahoma", 1, 48)); // NOI18N
        jLabelMin2.setForeground(new java.awt.Color(0, 204, 204));
        jLabelMin2.setText("-");
        jLabelMin2.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jLabelMin2.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jLabelMin2MouseClicked(evt);
            }
        });

        javax.swing.GroupLayout jPanel4Layout = new javax.swing.GroupLayout(jPanel4);
        jPanel4.setLayout(jPanel4Layout);
        jPanel4Layout.setHorizontalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel4Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabelMin1, javax.swing.GroupLayout.PREFERRED_SIZE, 29, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabelMin2))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabelClose1)
                .addGap(10, 10, 10))
        );
        jPanel4Layout.setVerticalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jLabelClose1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addGroup(jPanel4Layout.createSequentialGroup()
                .addComponent(jLabelMin1, javax.swing.GroupLayout.PREFERRED_SIZE, 0, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabelMin2, javax.swing.GroupLayout.PREFERRED_SIZE, 20, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, Short.MAX_VALUE))
        );

        jPanel5.setBackground(new java.awt.Color(222, 222, 222));
        jPanel5.setForeground(new java.awt.Color(255, 255, 255));
        jPanel5.setPreferredSize(new java.awt.Dimension(0, 6));

        javax.swing.GroupLayout jPanel5Layout = new javax.swing.GroupLayout(jPanel5);
        jPanel5.setLayout(jPanel5Layout);
        jPanel5Layout.setHorizontalGroup(
            jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 0, Short.MAX_VALUE)
        );
        jPanel5Layout.setVerticalGroup(
            jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 11, Short.MAX_VALUE)
        );

        jPanel6.setBackground(new java.awt.Color(244, 244, 244));

        jLabel1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Investasi/icons8_cheap_2_96px_2.png"))); // NOI18N

        txtKeluar.setFont(new java.awt.Font("Ebrima", 1, 30)); // NOI18N
        txtKeluar.setForeground(new java.awt.Color(153, 0, 0));
        txtKeluar.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        txtKeluar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtKeluarActionPerformed(evt);
            }
        });

        inKel1M.setBackground(new java.awt.Color(127, 19, 19));
        inKel1M.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        inKel1M.setForeground(new java.awt.Color(255, 255, 255));
        inKel1M.setText("1M");
        inKel1M.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                inKel1MMouseClicked(evt);
            }
        });

        inKel5K.setBackground(new java.awt.Color(127, 19, 19));
        inKel5K.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        inKel5K.setForeground(new java.awt.Color(255, 255, 255));
        inKel5K.setText("500K");
        inKel5K.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                inKel5KMouseClicked(evt);
            }
        });

        inKel1K.setBackground(new java.awt.Color(127, 19, 19));
        inKel1K.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        inKel1K.setForeground(new java.awt.Color(255, 255, 255));
        inKel1K.setText("100K");
        inKel1K.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                inKel1KMouseClicked(evt);
            }
        });

        limaPulMOut.setBackground(new java.awt.Color(127, 19, 19));
        limaPulMOut.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        limaPulMOut.setForeground(new java.awt.Color(255, 255, 255));
        limaPulMOut.setText("50M");
        limaPulMOut.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                limaPulMOutMouseClicked(evt);
            }
        });
        limaPulMOut.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                limaPulMOutActionPerformed(evt);
            }
        });

        sepMOut.setBackground(new java.awt.Color(127, 19, 19));
        sepMOut.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        sepMOut.setForeground(new java.awt.Color(255, 255, 255));
        sepMOut.setText("10M");
        sepMOut.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                sepMOutMouseClicked(evt);
            }
        });

        limaMOut.setBackground(new java.awt.Color(127, 19, 19));
        limaMOut.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        limaMOut.setForeground(new java.awt.Color(255, 255, 255));
        limaMOut.setText("5M");
        limaMOut.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                limaMOutMouseClicked(evt);
            }
        });

        jPanel13.setBackground(new java.awt.Color(204, 0, 51));

        jLabel6.setFont(new java.awt.Font("Ebrima", 1, 24)); // NOI18N
        jLabel6.setForeground(new java.awt.Color(255, 255, 255));
        jLabel6.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel6.setText("TOTAL PENGELUARAN");

        javax.swing.GroupLayout jPanel13Layout = new javax.swing.GroupLayout(jPanel13);
        jPanel13.setLayout(jPanel13Layout);
        jPanel13Layout.setHorizontalGroup(
            jPanel13Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jLabel6, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        jPanel13Layout.setVerticalGroup(
            jPanel13Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jLabel6, javax.swing.GroupLayout.DEFAULT_SIZE, 80, Short.MAX_VALUE)
        );

        javax.swing.GroupLayout jPanel6Layout = new javax.swing.GroupLayout(jPanel6);
        jPanel6.setLayout(jPanel6Layout);
        jPanel6Layout.setHorizontalGroup(
            jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel6Layout.createSequentialGroup()
                .addGap(27, 27, 27)
                .addComponent(jLabel1)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addGroup(jPanel6Layout.createSequentialGroup()
                        .addComponent(inKel1M)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(inKel5K)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(inKel1K))
                    .addComponent(txtKeluar)
                    .addGroup(jPanel6Layout.createSequentialGroup()
                        .addComponent(limaPulMOut, javax.swing.GroupLayout.PREFERRED_SIZE, 75, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(sepMOut, javax.swing.GroupLayout.PREFERRED_SIZE, 67, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(limaMOut)))
                .addContainerGap(19, Short.MAX_VALUE))
            .addComponent(jPanel13, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        jPanel6Layout.setVerticalGroup(
            jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel6Layout.createSequentialGroup()
                .addComponent(jPanel13, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGroup(jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel6Layout.createSequentialGroup()
                        .addGap(34, 34, 34)
                        .addComponent(jLabel1)
                        .addGap(0, 34, Short.MAX_VALUE))
                    .addGroup(jPanel6Layout.createSequentialGroup()
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addGroup(jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(limaMOut)
                            .addComponent(sepMOut)
                            .addComponent(limaPulMOut))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(txtKeluar, javax.swing.GroupLayout.PREFERRED_SIZE, 44, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(inKel1K)
                            .addGroup(jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                .addComponent(inKel1M)
                                .addComponent(inKel5K)))
                        .addGap(14, 14, 14))))
        );

        jPanel10.setBackground(new java.awt.Color(244, 244, 244));

        jPanel14.setBackground(new java.awt.Color(204, 0, 51));

        jLabel7.setFont(new java.awt.Font("Ebrima", 1, 24)); // NOI18N
        jLabel7.setForeground(new java.awt.Color(255, 255, 255));
        jLabel7.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel7.setText("TOTAL UANG DIINVESTKAN");

        javax.swing.GroupLayout jPanel14Layout = new javax.swing.GroupLayout(jPanel14);
        jPanel14.setLayout(jPanel14Layout);
        jPanel14Layout.setHorizontalGroup(
            jPanel14Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel14Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel7, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addContainerGap())
        );
        jPanel14Layout.setVerticalGroup(
            jPanel14Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel14Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel7, javax.swing.GroupLayout.DEFAULT_SIZE, 58, Short.MAX_VALUE)
                .addContainerGap())
        );

        jLabel2.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Investasi/icons8_cheap_2_96px_2.png"))); // NOI18N

        txtTotal.setEditable(false);
        txtTotal.setBackground(new java.awt.Color(255, 255, 255));
        txtTotal.setFont(new java.awt.Font("Ebrima", 1, 30)); // NOI18N
        txtTotal.setForeground(new java.awt.Color(153, 0, 0));
        txtTotal.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        txtTotal.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtTotalActionPerformed(evt);
            }
        });

        btHitung.setBackground(new java.awt.Color(255, 255, 255));
        btHitung.setFont(new java.awt.Font("Ebrima", 1, 18)); // NOI18N
        btHitung.setForeground(new java.awt.Color(127, 19, 19));
        btHitung.setText("HITUNG");
        btHitung.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        btHitung.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                btHitungMouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                btHitungMouseEntered(evt);
            }
        });
        btHitung.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btHitungActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel10Layout = new javax.swing.GroupLayout(jPanel10);
        jPanel10.setLayout(jPanel10Layout);
        jPanel10Layout.setHorizontalGroup(
            jPanel10Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel14, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addGroup(jPanel10Layout.createSequentialGroup()
                .addGap(28, 28, 28)
                .addComponent(jLabel2)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel10Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(txtTotal, javax.swing.GroupLayout.PREFERRED_SIZE, 192, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btHitung))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel10Layout.setVerticalGroup(
            jPanel10Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel10Layout.createSequentialGroup()
                .addComponent(jPanel14, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGroup(jPanel10Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel10Layout.createSequentialGroup()
                        .addGap(34, 34, 34)
                        .addComponent(jLabel2)
                        .addContainerGap(35, Short.MAX_VALUE))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel10Layout.createSequentialGroup()
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(txtTotal, javax.swing.GroupLayout.PREFERRED_SIZE, 44, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(btHitung)
                        .addGap(13, 13, 13))))
        );

        jPanel2.setBackground(new java.awt.Color(255, 255, 255));

        jPanel11.setBackground(new java.awt.Color(177, 22, 22));

        jLabel4.setFont(new java.awt.Font("Ebrima", 1, 30)); // NOI18N
        jLabel4.setForeground(new java.awt.Color(255, 255, 255));
        jLabel4.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel4.setText("DATA LAPORAN");

        javax.swing.GroupLayout jPanel11Layout = new javax.swing.GroupLayout(jPanel11);
        jPanel11.setLayout(jPanel11Layout);
        jPanel11Layout.setHorizontalGroup(
            jPanel11Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel11Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel4, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addContainerGap())
        );
        jPanel11Layout.setVerticalGroup(
            jPanel11Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel11Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel4, javax.swing.GroupLayout.DEFAULT_SIZE, 68, Short.MAX_VALUE)
                .addContainerGap())
        );

        tbLaporInvest.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(255, 255, 255)));
        tbLaporInvest.setFont(new java.awt.Font("Tahoma", 0, 16)); // NOI18N
        tbLaporInvest.setForeground(new java.awt.Color(153, 0, 51));
        tbLaporInvest.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Tanggal", "Masuk", "Keluar", "Total"
            }
        ) {
            Class[] types = new Class [] {
                java.lang.String.class, java.lang.String.class, java.lang.String.class, java.lang.String.class
            };
            boolean[] canEdit = new boolean [] {
                false, false, false, false
            };

            public Class getColumnClass(int columnIndex) {
                return types [columnIndex];
            }

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        tbLaporInvest.setGridColor(new java.awt.Color(255, 255, 255));
        tbLaporInvest.setSelectionBackground(new java.awt.Color(200, 21, 21));
        tbLaporInvest.setShowVerticalLines(false);
        tbLaporInvest.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                tbLaporInvestMouseClicked(evt);
            }
        });
        jScrollPane1.setViewportView(tbLaporInvest);
        if (tbLaporInvest.getColumnModel().getColumnCount() > 0) {
            tbLaporInvest.getColumnModel().getColumn(0).setResizable(false);
            tbLaporInvest.getColumnModel().getColumn(1).setResizable(false);
            tbLaporInvest.getColumnModel().getColumn(2).setResizable(false);
            tbLaporInvest.getColumnModel().getColumn(3).setResizable(false);
        }

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel11, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addComponent(jScrollPane1)
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addComponent(jPanel11, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, Short.MAX_VALUE)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 256, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, 0))
        );

        jPanel9.setBackground(new java.awt.Color(153, 0, 51));

        javax.swing.GroupLayout jPanel9Layout = new javax.swing.GroupLayout(jPanel9);
        jPanel9.setLayout(jPanel9Layout);
        jPanel9Layout.setHorizontalGroup(
            jPanel9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 80, Short.MAX_VALUE)
        );
        jPanel9Layout.setVerticalGroup(
            jPanel9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 40, Short.MAX_VALUE)
        );

        jPanel16.setBackground(new java.awt.Color(153, 0, 51));

        TextUser.setEditable(false);
        TextUser.setBackground(new java.awt.Color(153, 0, 0));
        TextUser.setFont(new java.awt.Font("Dialog", 0, 24)); // NOI18N
        TextUser.setForeground(new java.awt.Color(255, 255, 255));
        TextUser.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        TextUser.setSelectionColor(new java.awt.Color(153, 0, 51));
        TextUser.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                TextUserActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel16Layout = new javax.swing.GroupLayout(jPanel16);
        jPanel16.setLayout(jPanel16Layout);
        jPanel16Layout.setHorizontalGroup(
            jPanel16Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel16Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(TextUser, javax.swing.GroupLayout.PREFERRED_SIZE, 190, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(590, 590, 590))
        );
        jPanel16Layout.setVerticalGroup(
            jPanel16Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel16Layout.createSequentialGroup()
                .addGap(24, 24, 24)
                .addComponent(TextUser, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(24, Short.MAX_VALUE))
        );

        jPanel15.setBackground(new java.awt.Color(153, 0, 51));

        javax.swing.GroupLayout jPanel15Layout = new javax.swing.GroupLayout(jPanel15);
        jPanel15.setLayout(jPanel15Layout);
        jPanel15Layout.setHorizontalGroup(
            jPanel15Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 80, Short.MAX_VALUE)
        );
        jPanel15Layout.setVerticalGroup(
            jPanel15Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 40, Short.MAX_VALUE)
        );

        jPanel17.setBackground(new java.awt.Color(153, 0, 51));

        javax.swing.GroupLayout jPanel17Layout = new javax.swing.GroupLayout(jPanel17);
        jPanel17.setLayout(jPanel17Layout);
        jPanel17Layout.setHorizontalGroup(
            jPanel17Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 103, Short.MAX_VALUE)
        );
        jPanel17Layout.setVerticalGroup(
            jPanel17Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 40, Short.MAX_VALUE)
        );

        jPanel18.setBackground(new java.awt.Color(153, 0, 51));

        javax.swing.GroupLayout jPanel18Layout = new javax.swing.GroupLayout(jPanel18);
        jPanel18.setLayout(jPanel18Layout);
        jPanel18Layout.setHorizontalGroup(
            jPanel18Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 84, Short.MAX_VALUE)
        );
        jPanel18Layout.setVerticalGroup(
            jPanel18Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 40, Short.MAX_VALUE)
        );

        jPanel7.setBackground(new java.awt.Color(170, 39, 39));

        btInput.setBackground(new java.awt.Color(255, 255, 255));
        btInput.setFont(new java.awt.Font("Ebrima", 1, 36)); // NOI18N
        btInput.setForeground(new java.awt.Color(161, 22, 22));
        btInput.setText("INPUT ANGKA");
        btInput.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                btInputMouseClicked(evt);
            }
        });
        btInput.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btInputActionPerformed(evt);
            }
        });

        jButton1.setBackground(new java.awt.Color(255, 255, 255));
        jButton1.setFont(new java.awt.Font("Ebrima", 1, 36)); // NOI18N
        jButton1.setForeground(new java.awt.Color(161, 22, 22));
        jButton1.setText("TIPS INVESTASI");
        jButton1.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jButton1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jButton1MouseClicked(evt);
            }
        });
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });

        btRefreshinv.setBackground(new java.awt.Color(255, 255, 255));
        btRefreshinv.setFont(new java.awt.Font("Ebrima", 1, 36)); // NOI18N
        btRefreshinv.setForeground(new java.awt.Color(161, 22, 22));
        btRefreshinv.setText("REFRESH");
        btRefreshinv.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                btRefreshinvMouseClicked(evt);
            }
        });
        btRefreshinv.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btRefreshinvActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel7Layout = new javax.swing.GroupLayout(jPanel7);
        jPanel7.setLayout(jPanel7Layout);
        jPanel7Layout.setHorizontalGroup(
            jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel7Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(btInput, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jButton1, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(btRefreshinv, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap())
        );
        jPanel7Layout.setVerticalGroup(
            jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel7Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(btInput, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(btRefreshinv, javax.swing.GroupLayout.PREFERRED_SIZE, 75, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jButton1, javax.swing.GroupLayout.PREFERRED_SIZE, 102, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );

        jTextField1.setEditable(false);
        jTextField1.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jTextField1.setForeground(new java.awt.Color(153, 0, 0));
        jTextField1.setText("*Tekan Refresh Saat Pertama Kali Membuka Tampilan Ini !");
        jTextField1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jTextField1ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(jPanel16, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jPanel5, javax.swing.GroupLayout.DEFAULT_SIZE, 1397, Short.MAX_VALUE)
                    .addComponent(jPanel4, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(jPanel18, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(0, 0, 0)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jTextField1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                    .addComponent(jPanel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                    .addGroup(jPanel1Layout.createSequentialGroup()
                                        .addComponent(jPanel3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addGap(0, 0, 0)
                                        .addComponent(jPanel15, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addGap(0, 0, 0)
                                        .addComponent(jPanel6, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                                .addComponent(jPanel9, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(0, 0, 0)
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                    .addComponent(jPanel7, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                    .addComponent(jPanel10, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                                .addGap(0, 0, 0)
                                .addComponent(jPanel17, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))))
                .addGap(0, 0, Short.MAX_VALUE))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addComponent(jPanel4, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, Short.MAX_VALUE)
                .addComponent(jPanel5, javax.swing.GroupLayout.PREFERRED_SIZE, 11, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, 0)
                .addComponent(jPanel16, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(jPanel6, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jPanel10, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addComponent(jPanel3, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addComponent(jPanel15, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jPanel9, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jPanel18, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jPanel17, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(57, 57, 57)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                    .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jPanel7, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addGap(44, 44, 44)
                .addComponent(jTextField1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(28, 28, 28))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jButton1ActionPerformed

    private void jButton1MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jButton1MouseClicked
        saranInvest st = new saranInvest();
        st.setVisible(true);
    }//GEN-LAST:event_jButton1MouseClicked

    private void btInputMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btInputMouseClicked
        tbMasuk();
        tampilInvest();
    }//GEN-LAST:event_btInputMouseClicked

    private void setDefault() {
        txtMasuk.setText("0");
        txtKeluar.setText("0");
    }
    
    private void tbMasuk() {
        Calendar calendar = Calendar.getInstance();
        java.sql.Date ourJavaDateObject = new java.sql.Date(calendar.getTime().getTime());   
        int tM = Integer.parseInt(txtMasuk.getText());
        if (tM > 0) {
        try {
        String sql = "INSERT INTO investasi (tbTanggal, tbMasuk, tbKeluar, tbTotal) values(?,?,?,?)";
        java.sql.Connection conn = (Connection) Koneksi.configDB();
        java.sql.PreparedStatement pstm = conn.prepareStatement(sql);
        pstm.setDate(1, ourJavaDateObject);
        pstm.setString(2, txtMasuk.getText());
        pstm.setString(3, txtKeluar.getText());
        pstm.setString(4, txtTotal.getText());
        
        pstm.executeUpdate();
        pstm.close();
        UIManager.put("OptionPane.messageFont", new Font("Tahoma", Font.BOLD, 16));
        JOptionPane.showMessageDialog(null, "Input Investasi Terkonfirmasi");
            } catch (HeadlessException | SQLException e) {
        UIManager.put("OptionPane.messageFont", new Font("Tahoma", Font.BOLD, 16));
        JOptionPane.showMessageDialog(this, e.getMessage());
            } 
        }else {
            UIManager.put("OptionPane.messageFont", new Font("Tahoma", Font.BOLD, 16));
            JOptionPane.showMessageDialog(this, "Isi Berapa Nilai Yang Masuk ! ");
            txtMasuk.setText("0");
            txtKeluar.setText("0");
        }
    }
    
    private void btHitungActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btHitungActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_btHitungActionPerformed

    private void TextUserActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_TextUserActionPerformed
       
    }//GEN-LAST:event_TextUserActionPerformed

    private void txtTotalActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtTotalActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtTotalActionPerformed

    private void txtKeluarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtKeluarActionPerformed
        txtKeluar.setText("0");
    }//GEN-LAST:event_txtKeluarActionPerformed

    private void jLabelMin2MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabelMin2MouseClicked
        this.setState(JFrame.ICONIFIED);
    }//GEN-LAST:event_jLabelMin2MouseClicked

    private void jLabelMin1MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabelMin1MouseClicked
        this.setState(JFrame.ICONIFIED);
    }//GEN-LAST:event_jLabelMin1MouseClicked

    private void jLabelClose1MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabelClose1MouseClicked
                Investasi tb = new Investasi();
                tb.setVisible(false);
                Dompet dmp = new Dompet();  //FUNGSINYA UNTUK LOGOUT DARI KASIR KE LOGIN FORM
                dmp.setVisible(true);
                dmp.pack();
                dmp.setLocationRelativeTo(null);
                dmp.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
                //        this.setVisible(false);
                saranInvest st = new saranInvest();
                st.setVisible(false);
//                System.exit(1);
                this.dispose();
//        System.exit(0);
    }//GEN-LAST:event_jLabelClose1MouseClicked

    private void txtMasukActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtMasukActionPerformed
        txtMasuk.setText("0");
    }//GEN-LAST:event_txtMasukActionPerformed

    private void btHitungMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btHitungMouseClicked
        hitung();
    }//GEN-LAST:event_btHitungMouseClicked

    private void btHitungMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btHitungMouseEntered
        // TODO add your handling code here:
    }//GEN-LAST:event_btHitungMouseEntered

    private void tbLaporInvestMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_tbLaporInvestMouseClicked
              
    }//GEN-LAST:event_tbLaporInvestMouseClicked

    private void sMMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_sMMouseClicked
        satuM();
    }//GEN-LAST:event_sMMouseClicked
    
    private void satuM () {
        txtMasuk.setText("1000000");
    }
    
    private void limaKMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_limaKMouseClicked
        limaK();
    }//GEN-LAST:event_limaKMouseClicked

    private void inKel1MMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_inKel1MMouseClicked
        satuMkel();
    }//GEN-LAST:event_inKel1MMouseClicked

    private void satuMkel() {
        txtKeluar.setText("1000000");
    }
    private void inKel5KMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_inKel5KMouseClicked
        limaKkel();
    }//GEN-LAST:event_inKel5KMouseClicked

    private void inKel1KMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_inKel1KMouseClicked
        satuKkel();
    }//GEN-LAST:event_inKel1KMouseClicked

    private void satuKMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_satuKMouseClicked
        satuKin();
    }//GEN-LAST:event_satuKMouseClicked

    private void limaMMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_limaMMouseClicked
        limaMin();
    }//GEN-LAST:event_limaMMouseClicked

    private void sepMMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_sepMMouseClicked
        sepMin();
    }//GEN-LAST:event_sepMMouseClicked

    private void limaPulMActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_limaPulMActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_limaPulMActionPerformed

    private void limaPulMMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_limaPulMMouseClicked
        limaPulMin();
    }//GEN-LAST:event_limaPulMMouseClicked

    private void limaPulMOutMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_limaPulMOutMouseClicked
        limaPulMOut();
    }//GEN-LAST:event_limaPulMOutMouseClicked

    private void limaPulMOut() {
        txtKeluar.setText("50000000");
    }
    private void limaPulMOutActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_limaPulMOutActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_limaPulMOutActionPerformed

    private void sepMOutMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_sepMOutMouseClicked
        sepMOut();
    }//GEN-LAST:event_sepMOutMouseClicked

    private void sepMOut() {
        txtKeluar.setText("10000000");
    }
    
    private void limaMOutMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_limaMOutMouseClicked
        limaMOut();
    }//GEN-LAST:event_limaMOutMouseClicked

    private void btInputActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btInputActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_btInputActionPerformed

    private void jTextField1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTextField1ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jTextField1ActionPerformed

    private void btRefreshinvMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btRefreshinvMouseClicked
        tampilInvest();
        txtMasuk.setText("0");
        txtKeluar.setText("0");
        
    }//GEN-LAST:event_btRefreshinvMouseClicked

    private void btRefreshinvActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btRefreshinvActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_btRefreshinvActionPerformed
    
    private void limaMOut() {
        txtKeluar.setText("5000000");
    }
    
    private void limaPulMin() {
        txtMasuk.setText("50000000");
    }
    
    private void sepMin() {
        txtMasuk.setText("10000000");
    }
    
    private void limaMin() {
        txtMasuk.setText("5000000");
    }
    private void satuKin() {
        txtMasuk.setText("100000");
    }
    
    private void satuKkel() {
        txtKeluar.setText("100000");
    }
    
    private void limaKkel() {
        txtKeluar.setText("500000");
    }
    private void limaK () {
        txtMasuk.setText("500000");
    }
    
    private void hitung(){
        //Reference Variable
        Penampungan pen = new Penampungan();
        pen.setKeluar(Integer.parseInt(txtKeluar.getText()));
        pen.setMasuk(Integer.parseInt(txtMasuk.getText()));
//        HitungInvest hi = new HitungInvest(); //Coba Polimorfis disini tapi gagal        
//        String Total = String.valueOf(hi.readHitung());
        int tMasuk =  pen.getMasuk();
        int tKeluar = pen.getKeluar();
        int total = tMasuk - tKeluar;
        String Total = String.valueOf(total);
        txtTotal.setText(Total);
    }
    
    private void tampilInvest() {
        DefaultTableModel model = new DefaultTableModel();
        model.addColumn("Tanggal");
        model.addColumn("Masuk");
        model.addColumn("Keluar");
        model.addColumn("Total");
        
        
        //memanggil data dari database SQL
        try {
            String sql = "SELECT * FROM investasi";
            java.sql.Connection conn = (Connection) Koneksi.configDB();
            java.sql.Statement stm = conn.createStatement();
            java.sql.ResultSet rs = stm.executeQuery(sql);
            while (rs.next()) {
                model.addRow(new Object[]{
                    rs.getString(1), rs.getString(2),
                    rs.getString(3), rs.getString(4)});
                }
            tbLaporInvest.setModel(model);
        }catch (SQLException e) {
            UIManager.put("OptionPane.messageFont", new Font("Tahoma", Font.BOLD, 16));
            JOptionPane.showMessageDialog(null, "ERROR !");
            System.out.println("ERROR!" + e.getMessage());
        }
    }
    
    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Investasi.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Investasi.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Investasi.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Investasi.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            @Override
            public void run() {
                new Investasi().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JTextField TextUser;
    private javax.swing.JButton btHitung;
    private javax.swing.JButton btInput;
    private javax.swing.JButton btRefreshinv;
    private javax.swing.JButton inKel1K;
    private javax.swing.JButton inKel1M;
    private javax.swing.JButton inKel5K;
    private javax.swing.JButton jButton1;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabelClose1;
    private javax.swing.JLabel jLabelMin1;
    private javax.swing.JLabel jLabelMin2;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel10;
    private javax.swing.JPanel jPanel11;
    private javax.swing.JPanel jPanel12;
    private javax.swing.JPanel jPanel13;
    private javax.swing.JPanel jPanel14;
    private javax.swing.JPanel jPanel15;
    private javax.swing.JPanel jPanel16;
    private javax.swing.JPanel jPanel17;
    private javax.swing.JPanel jPanel18;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JPanel jPanel4;
    private javax.swing.JPanel jPanel5;
    private javax.swing.JPanel jPanel6;
    private javax.swing.JPanel jPanel7;
    private javax.swing.JPanel jPanel9;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTextField jTextField1;
    private javax.swing.JButton limaK;
    private javax.swing.JButton limaM;
    private javax.swing.JButton limaMOut;
    private javax.swing.JButton limaPulM;
    private javax.swing.JButton limaPulMOut;
    private javax.swing.JButton sM;
    private javax.swing.JButton satuK;
    private javax.swing.JButton sepM;
    private javax.swing.JButton sepMOut;
    private javax.swing.JTable tbLaporInvest;
    private javax.swing.JTextField txtKeluar;
    private javax.swing.JTextField txtMasuk;
    private javax.swing.JTextField txtTotal;
    // End of variables declaration//GEN-END:variables
}
